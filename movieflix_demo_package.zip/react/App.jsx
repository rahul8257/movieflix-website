/**
 * MovieFlix-Complete-Demo.jsx
 * A single-file React that contains a home, modal, auth demo and admin UI.
 * Drop this into src/App.jsx of a React project (Vite/CRA).
 */

import React, { useState, useEffect } from 'react';

const SAMPLE_MOVIES = [
  { id: 'm1', title: 'Demo Movie 1', year: 2023, genre: 'Action', desc: 'High-octane action demo.', img: 'https://via.placeholder.com/400x600?text=Poster+1' },
  { id: 'm2', title: 'Comedy Nights', year: 2021, genre: 'Comedy', desc: 'Light-hearted family comedy.', img: 'https://via.placeholder.com/400x600?text=Poster+2' },
  { id: 'm3', title: 'Thriller Night', year: 2022, genre: 'Thriller', desc: 'Edge-of-seat suspense.', img: 'https://via.placeholder.com/400x600?text=Poster+3' },
  { id: 'm4', title: 'Documentary Demo', year: 2019, genre: 'Documentary', desc: 'Informational and calm.', img: 'https://via.placeholder.com/400x600?text=Poster+4' },
  { id: 'm5', title: 'Romantic Tale', year: 2020, genre: 'Romance', desc: 'A touching love story.', img: 'https://via.placeholder.com/400x600?text=Poster+5' },
];

const styles = `
:root{--bg:#05060a;--card:#0f1720;--muted:#94a3b8;--accent:#e50914}
*{box-sizing:border-box}
body{margin:0;font-family:Inter,ui-sans-serif,system-ui, -apple-system,Segoe UI,Roboto,Helvetica Neue,Arial}
.app{min-height:100vh;background:linear-gradient(180deg,#05060a 0%, #071027 100%);color:#fff}
.header{display:flex;align-items:center;justify-content:space-between;padding:14px 20px;background:rgba(0,0,0,0.25)} 
.search{padding:8px 12px;border-radius:10px;border:1px solid rgba(255,255,255,0.06);background:rgba(255,255,255,0.03);color:#fff;min-width:220px}
.container{padding:22px}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:16px}
.card{background:var(--card);border-radius:10px;overflow:hidden;cursor:pointer;transition:transform .18s}
.card img{width:100%;height:260px;object-fit:cover}
.modal-bg{position:fixed;inset:0;background:rgba(0,0,0,0.7);display:flex;align-items:center;justify-content:center}
.modal{background:#071426;padding:18px;border-radius:10px;width:92%;max-width:520px}
.btn{padding:8px 12px;border-radius:8px;border:none;cursor:pointer}
.btn-primary{background:var(--accent);color:#fff}
`;

export default function App(){
  const [movies,setMovies] = useState(SAMPLE_MOVIES);
  const [query,setQuery] = useState('');
  const [selected,setSelected] = useState(null);
  const [view,setView] = useState('home');

  function filtered(){
    return movies.filter(m => m.title.toLowerCase().includes(query.toLowerCase()) || String(m.year).includes(query));
  }

  return (
    <div className="app">
      <style>{styles}</style>
      <header className="header">
        <div style={{display:'flex',gap:10,alignItems:'center'}} onClick={()=>setView('home')}>
          <div style={{width:40,height:40,borderRadius:8,background:'linear-gradient(45deg,#e50914,#ff6b6b)',display:'flex',alignItems:'center',justifyContent:'center',fontWeight:800}}>MF</div>
          <div><strong>MovieFlix</strong><div style={{fontSize:12,color:'#94a3b8'}}>Demo</div></div>
        </div>
        <input className="search" placeholder="Search..." onChange={e=>setQuery(e.target.value)} />
      </header>

      <div className="container">
        {view==='home' && (
          <div>
            <div style={{display:'flex',gap:12,alignItems:'center',marginBottom:12}}>
              <div style={{background:'rgba(255,255,255,0.04)',padding:'6px 8px',borderRadius:999}}>Categories</div>
              <div style={{marginLeft:'auto'}}>Showing {filtered().length}</div>
            </div>
            <div className="grid">
              {filtered().map(m=> (
                <div key={m.id} className="card" onClick={()=>setSelected(m)}>
                  <img src={m.img} alt={m.title} />
                  <div style={{padding:10,fontWeight:700}}>{m.title} <span style={{fontSize:12,color:'#94a3b8'}}>({m.year})</span></div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {selected && (
        <div className="modal-bg" onClick={()=>setSelected(null)}>
          <div className="modal" onClick={e=>e.stopPropagation()}>
            <h3>{selected.title} <small style={{color:'#94a3b8'}}>({selected.year})</small></h3>
            <p style={{color:'#94a3b8'}}>{selected.genre}</p>
            <p>{selected.desc}</p>
            <div style={{display:'flex',gap:8,marginTop:12}}>
              <button className="btn btn-primary">Watch Demo</button>
              <button className="btn" onClick={()=>setSelected(null)}>Close</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
